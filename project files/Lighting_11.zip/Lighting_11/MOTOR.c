/*
 * MOTOR.c
 *
 *  Created on: Aug 22, 2023
 *      Author: Dorgham
 */
#define F_CPU 8000000UL
#include"STD_TYPES.h"
#include"BIT_MATH.h"
#include"DIO.h"
#include "MOTOR.h"
#include <avr/io.h>
#include <util/delay.h>

void MOTOR_Init(void){
	DIO_SetPinDirection(MOTOR_PORT, MOTOR_EN, DIO_PIN_OUTPUT);
	DIO_SetPinDirection(MOTOR_PORT, MOTOR_IN1, DIO_PIN_OUTPUT);
	DIO_SetPinDirection(MOTOR_PORT, MOTOR_IN2, DIO_PIN_OUTPUT);

	DIO_SetPinValue(MOTOR_PORT, MOTOR_EN, DIO_PIN_HIGH);
	DIO_SetPinValue(MOTOR_PORT, MOTOR_IN1, DIO_PIN_LOW);
	DIO_SetPinValue(MOTOR_PORT, MOTOR_IN2, DIO_PIN_LOW);

}

void MOTOR_CWDirection(void){
	DIO_SetPinValue(MOTOR_PORT, MOTOR_IN1, DIO_PIN_LOW);
	DIO_SetPinValue(MOTOR_PORT, MOTOR_IN2, DIO_PIN_HIGH);
}

void MOTOR_CCDirection(void){
	DIO_SetPinValue(MOTOR_PORT, MOTOR_IN1, DIO_PIN_HIGH);
	DIO_SetPinValue(MOTOR_PORT, MOTOR_IN2, DIO_PIN_LOW);
}

void MOTOR_StopMotion(void){
	DIO_SetPinValue(MOTOR_PORT, MOTOR_IN1, DIO_PIN_LOW);
	DIO_SetPinValue(MOTOR_PORT, MOTOR_IN2, DIO_PIN_LOW);
}
