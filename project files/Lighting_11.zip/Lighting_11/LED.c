/*
 * LED.c

 *
 *  Created on: Sep 14, 2023
 *      Author: Dorgham
 */

#include"STD_TYPES.h"
#include"BIT_MATH.h"
#include"DIO.h"
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "CLCD.h"
#include "keypad.h"
#include "LED.h"

u8 Local_u8Key = 0xff;

void LEDS_INIT(void){
	DIO_SetPortDirection(LEDS_PORT, DIO_PORT_OUTPUT);
}

void LIVING_ROOM(void){
	while (1)
	{
		// Ask the user to turn the light on or off
		CLCD_voidLCD_Clear();
		CLCD_voidGoTo_X_Y(0, 0);
		CLCD_voidSrting("Press + to ON");
		CLCD_voidGoTo_X_Y(1, 0);
		CLCD_voidSrting("Press - to OFF");

		while (1)
		{
			Local_u8Key = KPD_GetPressedKey();
			if (Local_u8Key == '+')
			{
				// Turn on the living room light
				DIO_SetPinValue(LEDS_PORT, LIVING_ROOM_PIN, DIO_PIN_HIGH);
				break;
			}
			else if (Local_u8Key == '-')
			{
				// Turn off the living room light
				DIO_SetPinValue(LEDS_PORT, LIVING_ROOM_PIN, DIO_PIN_LOW);
				break;
			}
			_delay_ms(100);
		}
		CLCD_voidLCD_Clear();
		// Allow the user to go back to choose the room or exit
		CLCD_voidGoTo_X_Y(0, 0);
		CLCD_voidSrting("Press C to continue");
		CLCD_voidGoTo_X_Y(1, 0);
		CLCD_voidSrting("Press 0 to exit");


		while (1)
		{
			Local_u8Key = KPD_GetPressedKey();
			if ((Local_u8Key == '0') || Local_u8Key == 'C')
			{
				break;
			}

			_delay_ms(100);
		}
		if (Local_u8Key == '0' ){
			// Exit the living room lighting control loop
			break;
		}
		else if (Local_u8Key == 'C' ){
			// Stay in the living room lighting control loop
			continue;
		}
	}
}

void MASTER_BEDROOM(){
	while (1)
	{
		// Ask the user to turn the light on or off
		CLCD_voidLCD_Clear();
		CLCD_voidGoTo_X_Y(0, 0);
		CLCD_voidSrting("Press + to ON");
		CLCD_voidGoTo_X_Y(1, 0);
		CLCD_voidSrting("Press - to OFF");

		while (1)
		{
			Local_u8Key = KPD_GetPressedKey();
			if (Local_u8Key == '+')
			{
				// Turn on the master bedroom light
				DIO_SetPinValue(LEDS_PORT, MASTER_BEDROOM_PIN, DIO_PIN_HIGH);
				break;
			}
			else if (Local_u8Key == '-')
			{
				// Turn off the master bedroom light
				DIO_SetPinValue(LEDS_PORT, MASTER_BEDROOM_PIN, DIO_PIN_LOW);
				break;
			}
			_delay_ms(100);
		}
		CLCD_voidLCD_Clear();
		// Allow the user to go back to choose the room or exit
		CLCD_voidGoTo_X_Y(0, 0);
		CLCD_voidSrting("Press C to continue");
		CLCD_voidGoTo_X_Y(1, 0);
		CLCD_voidSrting("Press 0 to exit");


		while (1)
		{
			Local_u8Key = KPD_GetPressedKey();
			if ((Local_u8Key == '0') || Local_u8Key == 'C')
			{
				break;
			}

			_delay_ms(100);
		}
		if (Local_u8Key == '0' ){
			// Exit the Master Bedroom lighting control loop
			break;
		}
		else if (Local_u8Key == 'C' ){
			// Stay in the Master Bedroom lighting control loop
			continue;
		}
	}
}

void BEDROOM2(void){
	while (1)
	{
		// Ask the user to turn the light on or off
		CLCD_voidLCD_Clear();
		CLCD_voidGoTo_X_Y(0, 0);
		CLCD_voidSrting("Press + to ON");
		CLCD_voidGoTo_X_Y(1, 0);
		CLCD_voidSrting("Press - to OFF");

		while (1)
		{
			Local_u8Key = KPD_GetPressedKey();
			if (Local_u8Key == '+')
			{
			// Turn on Bedroom2 light
			DIO_SetPinValue(LEDS_PORT, BEDROOM2_PIN, DIO_PIN_HIGH);
			break;
			}
			else if (Local_u8Key == '-')
			{
				// Turn off Bedroom2 light
				DIO_SetPinValue(LEDS_PORT, BEDROOM2_PIN, DIO_PIN_LOW);
				break;
			}
			_delay_ms(100);
		}
		CLCD_voidLCD_Clear();
		// Allow the user to go back to choose the room or exit
		CLCD_voidGoTo_X_Y(0, 0);
		CLCD_voidSrting("Press C to continue");
		CLCD_voidGoTo_X_Y(1, 0);
		CLCD_voidSrting("Press 0 to exit");


		while (1)
		{
			Local_u8Key = KPD_GetPressedKey();
			if ((Local_u8Key == '0') || Local_u8Key == 'C')
			{
				break;
			}

			_delay_ms(100);
		}
		if (Local_u8Key == '0' ){
			// Exit the Bedroom2 lighting control loop
			break;
		}
		else if (Local_u8Key == 'C' ){
			// Stay in the Bedroom2 lighting control loop
			continue;
		}
	}
}

void BEDROOM3(void){
	while (1)
	{
		// Ask the user to turn the light on or off
		CLCD_voidLCD_Clear();
		CLCD_voidGoTo_X_Y(0, 0);
		CLCD_voidSrting("Press + to ON");
		CLCD_voidGoTo_X_Y(1, 0);
		CLCD_voidSrting("Press - to OFF");

		while (1)
		{
			Local_u8Key = KPD_GetPressedKey();
			if (Local_u8Key == '+')
			{
				// Turn on Bedroom3 light
				DIO_SetPinValue(LEDS_PORT, BEDROOM3_PIN, DIO_PIN_HIGH);
				break;
			}
			else if (Local_u8Key == '-')
			{
				// Turn off Bedroom3 light
				DIO_SetPinValue(LEDS_PORT, BEDROOM3_PIN, DIO_PIN_LOW);
				break;
			}
			_delay_ms(100);

		}
		CLCD_voidLCD_Clear();
		// Allow the user to go back to choose the room or exit
		CLCD_voidGoTo_X_Y(0, 0);
		CLCD_voidSrting("Press C to continue");
		CLCD_voidGoTo_X_Y(1, 0);
		CLCD_voidSrting("Press 0 to exit");


		while (1)
		{
			Local_u8Key = KPD_GetPressedKey();
			if ((Local_u8Key == '0') || Local_u8Key == 'C')
			{
				break;
			}

			_delay_ms(100);
		}
		if (Local_u8Key == '0' ){
			// Exit the Bedroom3 lighting control loop
			break;
		}
		else if (Local_u8Key == 'C' ){
			// Stay in the Bedroom3 lighting control loop
			continue;
		}
	}
}

void BATHROOM(void){
	while (1)
	{
		// Ask the user to turn the light on or off
		CLCD_voidLCD_Clear();
		CLCD_voidGoTo_X_Y(0, 0);
		CLCD_voidSrting("Press + to ON");
		CLCD_voidGoTo_X_Y(1, 0);
		CLCD_voidSrting("Press - to OFF");

		while (1)
		{
			Local_u8Key = KPD_GetPressedKey();
			if (Local_u8Key == '+')
			{
				// Turn on the bathroom light
				DIO_SetPinValue(LEDS_PORT, BATHROOM_PIN, DIO_PIN_HIGH);
				break;
			}
			else if (Local_u8Key == '-')
			{
				// Turn off the bathroom light
				DIO_SetPinValue(LEDS_PORT, BATHROOM_PIN, DIO_PIN_LOW);
				break;
			}
			_delay_ms(100);
		}
		CLCD_voidLCD_Clear();
		// Allow the user to go back to choose the room or exit
		CLCD_voidGoTo_X_Y(0, 0);
		CLCD_voidSrting("Press C to continue");
		CLCD_voidGoTo_X_Y(1, 0);
		CLCD_voidSrting("Press 0 to exit");


		while (1)
		{
			Local_u8Key = KPD_GetPressedKey();
			if ((Local_u8Key == '0') || Local_u8Key == 'C')
			{
				break;
			}

			_delay_ms(100);
		}
		if (Local_u8Key == '0' ){
			// Exit the bathroom lighting control loop
			break;
		}
		else if (Local_u8Key == 'C' ){
			// Stay in the bathroom lighting control loop
			continue;
		}
	}
}


void KITCHEN(void){
	while (1)
	{
		// Ask the user to turn the light on or off
		CLCD_voidLCD_Clear();
		CLCD_voidGoTo_X_Y(0, 0);
		CLCD_voidSrting("Press + to ON");
		CLCD_voidGoTo_X_Y(1, 0);
		CLCD_voidSrting("Press - to OFF");

		while (1)
		{
			Local_u8Key = KPD_GetPressedKey();
			if (Local_u8Key == '+')
			{
				// Turn on the Kitchen light
				DIO_SetPinValue(LEDS_PORT, KITCHEN_PIN, DIO_PIN_HIGH);
				break;
			}
			else if (Local_u8Key == '-')
			{
				// Turn off the Kitchen light
				DIO_SetPinValue(LEDS_PORT, KITCHEN_PIN, DIO_PIN_LOW);
				break;
			}
			_delay_ms(100);
		}
		CLCD_voidLCD_Clear();
		// Allow the user to go back to choose the room or exit
		CLCD_voidGoTo_X_Y(0, 0);
		CLCD_voidSrting("Press C to continue");
		CLCD_voidGoTo_X_Y(1, 0);
		CLCD_voidSrting("Press 0 to exit");


		while (1)
		{
			Local_u8Key = KPD_GetPressedKey();
			if ((Local_u8Key == '0') || Local_u8Key == 'C')
			{
				break;
			}

			_delay_ms(100);
		}
		if (Local_u8Key == '0' ){
			// Exit the Kitchen lighting control loop
			break;
		}
		else if (Local_u8Key == 'C' ){
			// Stay in the Kitchen lighting control loop
			continue;
		}
	}
}
