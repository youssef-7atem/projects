/*
 * MOTOR.h
 *
 *  Created on: Aug 22, 2023
 *      Author: Dorgham
 */

#ifndef MOTOR_H_
#define MOTOR_H_

/*configurations*/
#define MOTOR_PORT	DIO_PORTC
#define MOTOR_EN	DIO_PIN3
#define MOTOR_IN1	DIO_PIN4
#define MOTOR_IN2	DIO_PIN5

/*Prototypes*/
void MOTOR_Init(void);
void MOTOR_CWDirection(void);
void MOTOR_CCDirection(void);
void MOTOR_StopMotion(void);

#endif /* MOTOR_H_ */
