/*
 * LM35.c

 *
 *  Created on: Sep 14, 2023
 *      Author: Dorgham
 */

#include <avr/io.h>
#include "STD_TYPES.h"
#include "BIT_MATH.h"
#include "DIO.h"


void ADC_Configuration (void){
    ADMUX = (1 << REFS0) | (1 << ADLAR); // AVCC as reference voltage, left-adjusted result

    // Enable ADC and set ADC prescaler to 128
    ADCSRA = (1 << ADEN) | (1 << ADPS0) | (1 << ADPS1) | (1 << ADPS2);
}

u8 GetTemperature(){
    // Start ADC conversion
    ADCSRA |= (1 << ADSC);

    // Wait for ADC conversion to complete
    while (ADCSRA & (1 << ADSC));

    // Read ADC result
    u16 adc_value = ADC;
	DIO_SetPinDirection(DIO_PORTC, DIO_PIN7, DIO_PIN_INPUT);
    // Convert ADC value to temperature (adjust the conversion formula as per your LM35 specifications)
    u8 temperature = (u8)((adc_value * 500) / 1024 - 5); // Example conversion formula for LM35

    return temperature;
}



