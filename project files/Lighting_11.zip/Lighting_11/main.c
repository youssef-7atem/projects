/*
 * final.c
 *
 *  Created on: Sep 10, 2023
 *      Author: Dorgham
 */


#define F_CPU 8000000UL
#include <avr/io.h>
#include <util/delay.h>
#include "STD_TYPES.h"
#include "BIT_MATH.h"
#include "DIO.h"
#include "keypad.h"
#include "CLCD.h"
#include "MOTOR.h"
#include "LED.h"

int main()
{
	KPD_Init();
	LEDS_INIT();
	CLCD_CTRLInitl();
	first:
	while (1){
		u8 Local_u8Key = 0xff;
		Local_u8Key = KPD_GetPressedKey();
		if (Local_u8Key == 'C'){
			main_func:
			CLCD_voidInitl();
			CLCD_voidGoTo_X_Y(0, 0);
			CLCD_voidSrting("1 for AC");
			CLCD_voidGoTo_X_Y(1, 0);
			CLCD_voidSrting("2 for Light");

			ADC_Configuration();

			while (1){
				Local_u8Key = KPD_GetPressedKey();
				// Control the air conditioner
				if (Local_u8Key == '1')
				{
					CLCD_voidLCD_Clear();
	                u8 new_temp = GetTemperature();

					while (1){
		                u8 str_room_temp[3];
						str_room_temp[0] = new_temp / 10 + '0';  // Extract tens digit
						str_room_temp[1] = new_temp % 10 + '0';  // Extract ones digit
						str_room_temp[2] = '\0';            // Null-terminate the string
						// Show the current target temperature
						CLCD_voidLCD_Clear();

						CLCD_voidGoTo_X_Y(0, 0);
						CLCD_voidSrting("Temperature(C):");
						CLCD_voidGoTo_X_Y(1, 0);
						CLCD_voidSrting(str_room_temp);

						while (1){
							Local_u8Key = KPD_GetPressedKey();
							if (Local_u8Key == '+')
							{
								if (new_temp == 30){ // The maximum temperature is 30
									break;
								}
								else{
									new_temp++;
									break;
								}

							}
							else if (Local_u8Key == '-')
							{
								if (new_temp == 16){ // The minimum temperature is 16
									break;
								}
								else{
									new_temp--;
									break;
								}
							}
							else if (Local_u8Key == '=')
							{
								break;
							}
						}
						if (Local_u8Key == '+')
						{
							continue;
						}
						else if (Local_u8Key == '-')
						{
							continue;
						}
						else if (Local_u8Key == '=')
						{
							MOTOR_Init();
							if (new_temp > GetTemperature()){
								MOTOR_CWDirection();
								_delay_ms(5000);
							}
							else if (new_temp < GetTemperature()){
								MOTOR_CCDirection();
								_delay_ms(5000);
							}
							MOTOR_StopMotion();
							CLCD_voidLCD_Clear();
							// Allow the user to go back to choose the room or exit
							CLCD_voidGoTo_X_Y(0, 0);
							CLCD_voidSrting("Press C to continue");
							CLCD_voidGoTo_X_Y(1, 0);
							CLCD_voidSrting("Press / to exit");

							while (1)
							{
								Local_u8Key = KPD_GetPressedKey();
								if ((Local_u8Key == '/') || Local_u8Key == 'C')
								{
									break;
								}

								_delay_ms(100);
							}
							if (Local_u8Key == '/' ){
								CLCD_voidLCD_Clear();
								goto main_func;
							}
							else if (Local_u8Key == 'C' ){
								continue;
							}
						}

					}

				}

				else if (Local_u8Key == '2'){
                    // Control the lighting
                    while (1)
                    {
						// Ask the user which room they want to control
						CLCD_voidLCD_Clear();
						CLCD_voidGoTo_X_Y(0, 0);
						CLCD_voidSrting("1-LR 2-MB 3-B2");
						CLCD_voidGoTo_X_Y(1, 0);
						CLCD_voidSrting("4-B3 5-Bth 6-K");

						while (1)
						{
							Local_u8Key = KPD_GetPressedKey();
							if (Local_u8Key == '1')
							{
								LIVING_ROOM();
								break;
							}


							else if (Local_u8Key == '2')
							{
								MASTER_BEDROOM();
								break;
							}


							else if (Local_u8Key == '3')
							{
								BEDROOM2();
								break;
							}


							else if (Local_u8Key == '4')
							{
								BEDROOM3();
								break;
							}

							else if (Local_u8Key == '5')
							{
								BATHROOM();
								break;
							}


							else if (Local_u8Key == '6')
							{
								KITCHEN();
								break;
							}

							else if (Local_u8Key == '/'){
								goto main_func;
							}

							else if (Local_u8Key == '0') {
								break;
							}

							_delay_ms(100);


						}

						if (Local_u8Key == '0'){
							continue;
						}

                    }

				}
				else if (Local_u8Key == '0'){
					CLCD_voidLCD_Clear();
					goto first;

				}

				_delay_ms(100);
			}


		}

		_delay_ms(100);
	}

}
