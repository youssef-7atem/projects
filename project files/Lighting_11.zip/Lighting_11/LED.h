/*
 * LED.h
 *
 *  Created on: Sep 14, 2023
 *      Author: Dorgham
 */

#ifndef LED_H_
#define LED_H_


#define LEDS_PORT				DIO_PORTD

#define LIVING_ROOM_PIN			DIO_PIN0
#define MASTER_BEDROOM_PIN		DIO_PIN1
#define BEDROOM2_PIN			DIO_PIN2
#define BEDROOM3_PIN			DIO_PIN3
#define BATHROOM_PIN			DIO_PIN4
#define KITCHEN_PIN				DIO_PIN5


void LEDS_INIT(void);

#endif /* LED_H_ */
