//3amer and Abdullah

//task: make smart Door


//This task is different it is divided on two tasks




//Part 1 Guest

//first we need to check for the door bell always (push_button) ---> required 
//if it is not clicked do nothing 
//else if clicked 
//	print welcome mesage
//  send(1) to owner
//  recieve owner response
//  if ignore 
//     print no one could open now
//  else if open
//       printf(the door will open now for 30 seconds please enter)
//       open_door ---> servo
//else if enter pass
//      print(enter pass)
//      get pass from keypad
//      if(pass=std_pass){open}
//       else if(pass!=std_pass){
//	let him try again for 3 times if any of them right send(5) print(door will open for 30 seconds please enter)
//  if wrong in the fourth time then Alarm_on() and print("there some one who trried the password 3 times wrong on the door")











//part 2 Owner
// Always check if recieved data==1 or not
// if it is==1
// then ask the owner what to do and take the get_pressed_key
//now let's control according to owner choice
// if ignore send 0
//else if open send 2
//else if enter pass send 3 then check for recieved data if it is==5 the print he entered password correctly and door opened for him





		          