/*
 * USART.c
 *
 *  Created on: Aug 30, 2023
 *      Author: yousi
 */
#include "STD_TYPES.h"
#include "BIT_MATH.h"
#include <avr/io.h>
#include "USART.h"

void UART_voidInit(void)
{
	// frame format --> 8 bit data , 1 bit stop , no parity
	// word size --> from the data sheet
	SET_BIT(UCSRC,UCSRC_UCSZ1);
	SET_BIT(UCSRC,UCSRC_UCSZ0);
	CLR_BIT(UCSRB,UCSRB_UCSZ2);

	// stop bit
	CLR_BIT(UCSRC,UCSRC_USBS);

	// PARITY --> no parity
	CLR_BIT(UCSRC,UCSRC_UPM0);
	CLR_BIT(UCSRC,UCSRC_UPM1);

	// SET BAUD RATE --> 9600
	UBRRL=51;
	UBRRH=0;

	// ASYNCHRONOUS
	CLR_BIT(UCSRC,UCSRC_UMSEL);

	//ENABLE TX , RX
	SET_BIT(UCSRB,UCSRB_TXEN);
	SET_BIT(UCSRB,UCSRB_RXEN);

}
void UART_voidSendData(u8 Data_u8Copy){

	// wait flag UDRE to finish --> empty or not
	while(GET_BIT(UCSRA,UCSRA_UDRE)==0);
	UDR = Data_u8Copy;
}
u8 UART_voidRecieveData(void)
{
	while(GET_BIT(UCSRA,UCSRA_RXC)==0);
	return UDR;
}
