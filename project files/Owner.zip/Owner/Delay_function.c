#include <avr/io.h>
#include <avr/interrupt.h>

volatile uint8_t timer_flag = 0;

// Timer1 Compare Match A interrupt service routine
ISR(TIMER1_COMPA_vect) {
    timer_flag = 1; // Set the flag when the compare match occurs
}

// Function to initialize Timer1 for delay
void timer1_init() {
    // Set Timer1 in CTC mode (Clear Timer on Compare Match)
    TCCR1B |= (1 << WGM12);

    // Set a higher prescaler to slow down the timer
    TCCR1B |= (1 << CS12); // Prescaler = 256

    // Calculate the compare match value for a 1-millisecond delay
    OCR1A = 29 - 1; // 31 counts for 1 millisecond

    // Enable Timer1 Compare Match A interrupt
    TIMSK |= (1 << OCIE1A);
}

// Function to create a delay in milliseconds
void custom_delay_ms(uint16_t milliseconds) {
    // Initialize timer_flag
    timer_flag = 0;

    // Start the timer
    timer1_init();

    // Wait until the required number of milliseconds has passed
    while (milliseconds > 0) {
        if (timer_flag) {
            timer_flag = 0;
            milliseconds--;
        }
    }

    // Turn off Timer1
    TCCR1B = 0;
}
