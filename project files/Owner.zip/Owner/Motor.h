/*
 * Motor.h
 *
 *  Created on: Aug 22, 2023
 *      Author: yousi
 */

#ifndef MOTOR_H_
#define MOTOR_H_

// Configurations
#define MOTOR_PORT DIO_PORTD
#define MOTOR_EN   DIO_PIN0
#define MOTOR_IN1  DIO_PIN1
#define MOTOR_IN2  DIO_PIN2


// Configurations for switches
#define SWITCH_PORT DIO_PORTA
#define SWITCH_s1   DIO_PIN0
#define SWITCH_s2  DIO_PIN1
#define SWITCH_s3  DIO_PIN2

// PROTOTYPRS
void MOTOR_Init(void);
void MOTOR_CWDirection(void);
void MOTOR_CCWDirection(void);
void MOTOR_StopMotion(void);
#endif /* MOTOR_H_ */
