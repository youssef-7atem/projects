/*
 * Owner_Guest.h
 *
 *  Created on: Sep 8, 2023
 *      Author: Abdalla
 */

#ifndef OWNER_GUEST_H_
#define OWNER_GUEST_H_


#define button_is_clicked 1

#define ignore_button '0'
#define open_button '1'
#define pass_check_button '2'
#define exit_button '3'
#define pass_correct '4'
#define no_correct_pass '5'

u8 owner_options(void);
void owner_CTRL(key);

#endif /* OWNER_GUEST_H_ */
