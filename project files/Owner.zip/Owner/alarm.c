#include "BIT_MATH.h"
#include "STD_TYPES.h"
#include "DIO.h"
#include "alarm.h"
#include<util/delay.h>
#include<avr/io.h>
#include "CLCD.h"

void buzzer_Led_on(void)
{
	DIO_SetPinDirection(DIO_PORTC, DIO_PIN5, DIO_OUTPUT);
	DIO_SetPinDirection(DIO_PORTC, DIO_PIN7, DIO_OUTPUT);
	DIO_SetPinValue(DIO_PORTC,DIO_PIN5, DIO_HIGH);
	DIO_SetPinValue(DIO_PORTC, DIO_PIN7, DIO_HIGH);
	_delay_ms(400);
	DIO_SetPinValue(DIO_PORTC, DIO_PIN5, DIO_LOW);
	DIO_SetPinValue(DIO_PORTC,DIO_PIN7, DIO_LOW);

}

void alarm_on(void) {
  // Do the buzzer_on() and detector_led_on() functions 9 times.
	CLCD_voidSrting("threat detected");
	for (int i = 0; i < 5; i++) {
		buzzer_Led_on();
		_delay_ms(350);
  }
}

