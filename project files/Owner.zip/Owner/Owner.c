/*
 * Owner_Guest.c
 *
 *  Created on: Sep 8, 2023
 *      Author: Abdalla
 */
#include"STD_TYPES.h"
#include"BIT_MATH.h"
#include<avr/io.h>
#include"Keypad.h"
#include"CLCD.h"
#include"USART.h"
#include"alarm.h"
#include"Owner_Guest.h"
#include<util/delay.h>
#include <avr/interrupt.h>

u8 owner_options(void){
	timer1_init();
	sei();
	u8 key=KPD_NOT_PRESSED_KEY;
	int counter =0;
	CLCD_voidInitl();
	buzzer_Led_on();
	CLCD_voidSrting("Doorbell rings");

	custom_delay_ms(2000);
	//_delay_ms(2000);
	//buzzer_on();detector_led();
	CLCD_voidLCD_Clear();
	CLCD_voidSrting("ignore press 0");

	custom_delay_ms(2000);
	//_delay_ms(2000);
	CLCD_voidLCD_Clear();
	CLCD_voidSrting("open press 1");

	custom_delay_ms(2000);
	//_delay_ms(2000);
	CLCD_voidLCD_Clear();
	CLCD_voidSrting("password check");
	CLCD_voidGoTo_X_Y(1,0);
	CLCD_voidSrting("press 2");

	custom_delay_ms(2000);
	//_delay_ms(2000);
	CLCD_voidLCD_Clear();
	CLCD_voidSrting("repeat press 3");

	custom_delay_ms(2000);
	//_delay_ms(2000);
	CLCD_voidLCD_Clear();
	CLCD_voidSrting("Please choose :");
	//CLCD_voidGoTo_X_Y(1,0);
	//CLCD_voidSrting("3 sec to choose");

	custom_delay_ms(2000);
	//_delay_ms(2000);
	//CLCD_voidLCD_Clear();
	KPD_Init();
	while(key==KPD_NOT_PRESSED_KEY){
		if(counter == 5000){
			CLCD_voidInitl();
			CLCD_voidSrting("Doorbell rings");

			custom_delay_ms(2000);
			//_delay_ms(2000);
			//buzzer_on();detector_led();
			CLCD_voidLCD_Clear();
			CLCD_voidSrting("ignore press 0");

			custom_delay_ms(2000);
			//_delay_ms(2000);
			CLCD_voidLCD_Clear();
			CLCD_voidSrting("open press 1");

			custom_delay_ms(2000);
			//_delay_ms(2000);
			CLCD_voidLCD_Clear();
			CLCD_voidSrting("password check");
			CLCD_voidGoTo_X_Y(1,0);
			CLCD_voidSrting("press 2");

			custom_delay_ms(2000);
			//_delay_ms(2000);
			CLCD_voidLCD_Clear();
			CLCD_voidSrting("repeat press 3");

			custom_delay_ms(2000);
			//_delay_ms(2000);
			CLCD_voidLCD_Clear();
			CLCD_voidSrting("Please choose :");

			custom_delay_ms(2000);
			//_delay_ms(2000);
			KPD_Init();
			counter =0;
		}
		key=KPD_GETPressedKey();
		counter++;
	}
	custom_delay_ms(1000);
	_delay_ms(1000);
	CLCD_voidLCD_Clear();

	return key;
}

void owner_CTRL(key){
	timer1_init();
	sei();
	if(key== ignore_button)
	{
		UART_voidSendData(ignore_button);
	}

	else if(key ==open_button)
	{
		UART_voidSendData(open_button);
	}
	else if(key ==pass_check_button)
	{

		UART_voidSendData(pass_check_button);
		u8 threat='9';
		do {
			threat = UART_voidRecieveData();
		} while (threat != no_correct_pass);

		//if(UART_voidRecieveData()==no_correct_pass) {
			alarm_on();
		//}
			}

	else if(key ==exit_button){
		CLCD_voidSrting("Exit is Done");
	}
	else{
		CLCD_voidSrting("wrong input!");

		custom_delay_ms(1000);
		//_delay_ms(1000);
		u8 choice= owner_options();
		owner_CTRL(choice);


	}

}
