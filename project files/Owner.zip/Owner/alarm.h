/*
 * alarm.h
 *
 *  Created on: Sep 12, 2023
 *      Author: yousi
 */

#ifndef ALARM_H_
#define ALARM_H_

void buzzer_Led_on(void); // once the door-bell is clicked the buzzer and led will be on
void alarm_on(void); // in case of wrong password entered


#endif /* ALARM_H_ */
