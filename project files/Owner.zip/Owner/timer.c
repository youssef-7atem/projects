/* * timer.c
 *
 *  Created on: Aug 27, 2023
 *      Author: yousi
 */
#include "STD_TYPES.h"
#include "BIT_MATH.h"
#include "timer.h"
#include <avr/io.h>
#define NULL ((void*)0)
void (*TIMER0_pvCallBackFunc)(void)= NULL;
/*void TIMER_voidInit(void)
{
#if(TIMER_Init_State==TIMER_u8_Init_State_Disable)
CLR_BIT(TCCR0,TCCR0_CS02);
CLR_BIT(TCCR0,TCCR0_CS01);
CLR_BIT(TCCR0,TCCR0_CS00);
#elif(TIMER_Init_State==TIMER_u8_Init_State_Disable)

}*/
void TIMER0_voidINIT(void){
	// CHOOSE
	CLR_BIT(TCCR0,TCCR0_WGM00);
	SET_BIT(TCCR0,TCCR0_WGM01);

	OCR0 = 250;

	SET_BIT(TIMSK,TIMSK_OCIE0);

	CLR_BIT(TCCR0,TCCR0_CS00);
	SET_BIT(TCCR0,TCCR0_CS01);
	CLR_BIT(TCCR0,TCCR0_CS02);
}

void TIMER0_voidINIT1(void){
	// CHOOSE
	CLR_BIT(TCCR0,TCCR0_WGM00);
	SET_BIT(TCCR0,TCCR0_WGM01);

	OCR0 = 250;

	SET_BIT(TIMSK,TIMSK_OCIE0);

	CLR_BIT(TCCR0,TCCR0_CS00);
	SET_BIT(TCCR0,TCCR0_CS01);
	CLR_BIT(TCCR0,TCCR0_CS02);
}
u8 TIMER0_u8SetCallBack(void(*Copy_pvCallBackFunc)){

	u8 u8ErrorStatus_Local=OK;
	if(Copy_pvCallBackFunc!= NULL){
		TIMER0_pvCallBackFunc =Copy_pvCallBackFunc;
	}
	else{
		u8ErrorStatus_Local= NOT_OK;
	}
	return u8ErrorStatus_Local;
}
void __vector_10(void) __attribute__((signal));
void __vector_10(void)
{
	if(TIMER0_pvCallBackFunc!=0){
		TIMER0_pvCallBackFunc();
	}
}

void TIMER1_voidINIT(void){
// MODE FAST PWM
	SET_BIT(TCCR1A,TCCR1A_COM1A1);
	SET_BIT(TCCR1A,TCCR1A_COM1A0);
	// SETTING WAVEFORM
	SET_BIT(TCCR1A,TCCR1A_WGM10);
	SET_BIT(TCCR1A,TCCR1A_WGM11);
	SET_BIT(TCCR1B,TCCR1B_WGM12);
	SET_BIT(TCCR1B,TCCR1B_WGM13);
	// SETTING THE PRESCALER
	TCCR1B&=PRESCALER_MASK;
	TCCR1B|=DIVID_BY_8;

}
void TIMER1_voidSetChannelACompareMatch(u16 Copy_u16CompareMatch){
	OCR1A=Copy_u16CompareMatch;

}
void TIMER1_voidSetTopTicks(u16 Copy_u16TopTicks){
	ICR1=Copy_u16TopTicks;

}
