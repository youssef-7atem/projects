/*
 * USART.h
 *
 *  Created on: Aug 30, 2023
 *      Author: yousi
 */

#ifndef USART_H_
#define USART_H_
// configuration bits
// USART Control and Status Register A � UCSRA
#define UCSRA_RXC    7  // USART RECEIVE COMPLETE
#define UCSRA_TXC    6  // USART TRANSMIT COMPLETE
#define UCSRA_UDRE   5  // USART Data Register Empty
#define UCSRA_FE     4  // Frame Error
#define UCSRA_DOR    3  // Data OverRun
#define UCSRA_PE     2  // Parity Error
#define UCSRA_U2X    1  // Double the USART Transmission Speed
#define UCSRA_MPCM   0  // Multi-processor Communication Mode

// USART Control and Status Register B � UCSRB
#define UCSRB_RXCIE  7  // RX Complete Interrupt Enable
#define UCSRB_TXCIE  6  // TX Complete Interrupt Enable
#define UCSRB_UDRIE  5  // USART Data Register Empty Interrupt Enable
#define UCSRB_RXEN   4  // Receiver Enable
#define UCSRB_TXEN   3  // Transmitter Enable
#define UCSRB_UCSZ2  2  // Character Size
#define UCSRB_RXB8   1  // Receive Data Bit 8
#define UCSRB_TXB8   0  // Transmit Data Bit 8

// USART Control and Status Register C � UCSRC
#define UCSRC_URSEL  7  // Register Select
#define UCSRC_UMSEL  6  // USART Mode Select
#define UCSRC_UPM1   5  // USART Mode Select
#define UCSRC_UPM0   4  // USART Mode Select
#define UCSRC_USBS   3  // Stop Bit Select
#define UCSRC_UCSZ1  2  // Character Size
#define UCSRC_UCSZ0  1  // Character Size
#define UCSRC_UCPOL  0  // Clock Polarity

// functions
void UART_voidInit(void);
void UART_voidSendData(u8 Data_u8Copy);
u8 UART_voidRecieveData(void);
#endif /* USART_H_ */
