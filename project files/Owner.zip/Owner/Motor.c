/*
 * Motor.c
 *
 *  Created on: Aug 22, 2023
 *      Author: yousi
 */
#define F_CPU 8000000UL
#include "STD_TYPES.h"
#include "BIT_MATH.h"
#include "DIO.h"
#include "Motor.h"
#include <util/delay.h>

void MOTOR_Init(void)
{
DIO_SetPinDirection(MOTOR_PORT, MOTOR_EN, DIO_OUTPUT);
DIO_SetPinDirection(MOTOR_PORT, MOTOR_IN1, DIO_OUTPUT);
DIO_SetPinDirection(MOTOR_PORT, MOTOR_IN2, DIO_OUTPUT);

DIO_SetPinValue(MOTOR_PORT, MOTOR_EN, DIO_HIGH);// ENABLE MOTOR A ON H-BRIDGE
DIO_SetPinValue(MOTOR_PORT, MOTOR_IN1, DIO_LOW); // AT INITIALIZATION IN AT LOW
DIO_SetPinValue(MOTOR_PORT, MOTOR_IN2, DIO_LOW); // AT INITIALIZATION IN AT LOW

}
void MOTOR_CWDirection(void)
{
DIO_SetPinValue(MOTOR_PORT, MOTOR_IN1, DIO_LOW);
DIO_SetPinValue(MOTOR_PORT, MOTOR_IN1, DIO_HIGH);


}
void MOTOR_CCWDirection(void)
{
	DIO_SetPinValue(MOTOR_PORT, MOTOR_IN1, DIO_HIGH);
	DIO_SetPinValue(MOTOR_PORT, MOTOR_IN1, DIO_LOW);

}
void MOTOR_StopMotion(void){
	DIO_SetPinValue(MOTOR_PORT, MOTOR_IN1, DIO_LOW);
	DIO_SetPinValue(MOTOR_PORT, MOTOR_IN1, DIO_LOW);
}

