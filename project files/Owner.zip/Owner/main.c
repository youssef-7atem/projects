#include"STD_TYPES.h"
#include"BIT_MATH.h"
#include<avr/io.h>
#include"keypad.h"
#include"DIO.h"
#include"CLCD.h"
#include"USART.h"
#include "alarm.h"
#include"Owner_Guest.h"
#include <avr/interrupt.h>
#include<util/delay.h>

//part 2 Owner
void main(void)
{
	while(1){
	DIO_SetPortDirection(CLCD_DATA_PORT, DIO_PORT_OUTPUT); // LCD keypad on PORTA
	DIO_SetPinDirection(CLCD_CTRL_PORT, DIO_PIN0, DIO_OUTPUT); // LCD RS on PIN0 --> PORTC
	DIO_SetPinDirection(CLCD_CTRL_PORT, DIO_PIN1, DIO_OUTPUT); // LCD RW on PIN1 --> PORTC
	DIO_SetPinDirection(CLCD_CTRL_PORT, DIO_PIN2, DIO_OUTPUT); // LCD E on PIN2 --> PORTC
	UART_voidInit();


	while(UART_voidRecieveData()!=button_is_clicked)
	{

	}

	u8 choice = owner_options();
	CLCD_voidInitl();
	//owner_options();
	owner_CTRL(choice);
	}
}
